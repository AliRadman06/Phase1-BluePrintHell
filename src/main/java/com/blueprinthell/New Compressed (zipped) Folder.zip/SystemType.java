package com.blueprinthell.model;

public enum SystemType {
    START,
    PROCESSING,
    END
}
